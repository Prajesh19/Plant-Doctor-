# Plant Doctor UI

```bash
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000. No API key needed. The diagnosis logic lives in `plant_doctor.py`
(add causes to `CAUSES`, symptoms to `SYMPTOMS`); `app.py` serves it as `POST /diagnose`.
