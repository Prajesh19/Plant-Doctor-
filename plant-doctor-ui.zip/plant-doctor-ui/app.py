from flask import Flask, jsonify, render_template, request

import plant_doctor

app = Flask(__name__)


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/diagnose")
def diagnose():
    text = ((request.get_json(silent=True) or {}).get("text") or "").strip()
    if len(text) < 3:
        return jsonify(error="Tell me what you see on your plant, or tap a few symptoms below."), 400
    if len(text) > 500:
        return jsonify(error="Please keep it under 500 characters."), 400
    return jsonify(plant_doctor.analyze(text))


if __name__ == "__main__":
    app.run(debug=True)
