"""Plant Doctor: describe your sick houseplant in plain English, get likely causes and fixes.
No API key, no installs. Run:  python plant_doctor.py   (or: python plant_doctor.py "leaves turning yellow and soil is wet")
"""
import re
import sys

# 1. What the user might say -> a symptom label (regex patterns)
SYMPTOMS = {
    "yellow_leaves": r"yellow|yellowing",
    "brown_tips": r"brown (tips|edges)|crispy|dry (tips|edges)|burnt (tips|edges)",
    "drooping": r"droop|wilt|limp|sagging|floppy",
    "leaf_drop": r"dropping leaves|losing leaves|leaves (are )?falling|leaf drop|shedding",
    "leggy": r"leggy|stretch|long thin stems|reaching|leaning",
    "mushy": r"mushy|black stem|rotting|rotten|squishy|smells",
    "spots": r"spots|blotch|patches",
    "webbing": r"web|webbing|tiny (red )?dots|stippl",
    "gnats": r"gnats|tiny flies|small flies|fruit flies",
    "pale": r"pale|faded|washed out|bleached",
    "curling": r"curl|crinkl|rolled",
    "slow_growth": r"not growing|slow growth|stunted|no new (growth|leaves)",
    "soil_wet": r"soil (is )?(wet|soggy|damp|waterlogged)|always wet|never dries|overwater",
    "soil_dry": r"soil (is )?(dry|hard|cracked)|bone dry|pulling away|underwater|forgot to water",
    "roots_out": r"roots (are )?(coming|growing|poking|circling)|root ?bound|pot (is )?too small",
    "bright_sun": r"direct sun|full sun|south window|sunburn|scorch",
    "dark_room": r"dark|low light|no sun|north window|dim",
    "cold_draft": r"cold|draft|draught|air con|\bac\b|heater|radiator",
}
NEG = r"\b(no|not|isn'?t|aren'?t|don'?t|without|never|none)\b[^.,;!?]*$"

# 2. Possible causes: symptom weights (higher = stronger clue) and what to do
CAUSES = {
    "Overwatering": ({"yellow_leaves": 3, "soil_wet": 5, "mushy": 4, "drooping": 2, "leaf_drop": 2, "gnats": 3, "spots": 1},
        ["Stop watering until the top 3-5 cm of soil is dry.", "Check the roots: healthy ones are firm and pale, rotten ones are brown and mushy; trim the rotten ones.",
         "Make sure the pot has drainage holes and never leave it standing in water."]),
    "Underwatering": ({"brown_tips": 3, "soil_dry": 5, "drooping": 3, "curling": 3, "leaf_drop": 2, "yellow_leaves": 1},
        ["Water slowly until it drains from the bottom, then let the pot drain fully.", "If soil has pulled away from the pot, soak the pot in a bucket for 20 minutes.",
         "Water on a schedule based on soil dryness, not the calendar."]),
    "Too little light": ({"leggy": 5, "dark_room": 5, "pale": 3, "slow_growth": 3, "leaf_drop": 1, "yellow_leaves": 1},
        ["Move it closer to a bright window (bright indirect light suits most houseplants).", "Rotate the pot weekly so all sides get light.", "Consider a cheap LED grow light in winter."]),
    "Too much direct sun": ({"bright_sun": 5, "brown_tips": 3, "pale": 3, "spots": 2, "curling": 2, "drooping": 1},
        ["Move it back from the window or hang a sheer curtain.", "Trim badly scorched leaves; they will not recover.", "Introduce it to brighter spots gradually."]),
    "Low humidity or cold/dry air": ({"brown_tips": 4, "curling": 2, "cold_draft": 4, "leaf_drop": 2, "drooping": 1},
        ["Keep it away from heaters, radiators and air-conditioning vents.", "Group plants together or use a pebble tray to raise humidity.", "Avoid temperatures below about 12 C."]),
    "Spider mites": ({"webbing": 6, "pale": 2, "spots": 2, "curling": 1, "yellow_leaves": 1},
        ["Isolate the plant and rinse leaves, especially undersides, in the shower.", "Wipe leaves with insecticidal soap or neem oil solution every 5-7 days for a few weeks.", "Raise humidity; mites like dry air."]),
    "Fungus gnats": ({"gnats": 6, "soil_wet": 3, "slow_growth": 1},
        ["Let the soil dry out more between waterings.", "Use yellow sticky traps for adult gnats.", "Top the soil with a 1 cm layer of sand or water with diluted hydrogen peroxide (1:4)."]),
    "Root-bound or nutrient-hungry": ({"roots_out": 6, "slow_growth": 4, "yellow_leaves": 2, "drooping": 1, "pale": 2},
        ["Repot into a pot 2-5 cm wider with fresh potting mix.", "Feed with diluted balanced fertilizer in spring and summer.", "Gently loosen circling roots before replanting."]),
}


def find_symptoms(text):
    """Return (symptoms present, symptoms the user explicitly ruled out)."""
    text = text.lower().replace("\u2019", "'")
    present, absent = set(), set()
    for name, pattern in SYMPTOMS.items():
        m = re.search(pattern, text)
        if m:
            negated = re.search(NEG, text[max(0, m.start() - 25):m.start()])
            (absent if negated else present).add(name)
    return present, absent


def diagnose(text):
    present, absent = find_symptoms(text)
    scores = {}
    for cause, (weights, _) in CAUSES.items():
        score = sum(w for s, w in weights.items() if s in present)
        score -= sum(w * 0.5 for s, w in weights.items() if s in absent)   # ruled-out clues count against
        if score > 0:
            scores[cause] = score
    total = sum(scores.values())
    ranked = sorted(scores.items(), key=lambda kv: -kv[1])[:3]
    return present, [(c, round(100 * s / total)) for c, s in ranked]


def report(text):
    present, results = diagnose(text)
    if not results:
        return ("I couldn't spot any symptoms. Try describing what you see, e.g. "
                "'yellow leaves, soil stays wet' or 'brown crispy tips and drooping'.")
    lines = ["Symptoms I noticed: " + ", ".join(s.replace("_", " ") for s in sorted(present)), ""]
    for i, (cause, pct) in enumerate(results, 1):
        lines.append(f"{i}. {cause}  (~{pct}% of the evidence)")
        lines += [f"   - {tip}" for tip in CAUSES[cause][1]]
        lines.append("")
    if results[0][1] < 45:
        lines.append("Several causes are close. Tell me about soil moisture, light, and whether you see pests to narrow it down.")
    lines.append("Tip: change one thing at a time and give the plant 2-3 weeks to respond.")
    return "\n".join(lines)


def main():
    if len(sys.argv) > 1:
        print(report(" ".join(sys.argv[1:])))
        return
    print("Plant Doctor. Describe what's wrong with your plant (blank line to quit).\n")
    while True:
        text = input("Your plant> ").strip()
        if not text:
            print("Good luck with your plant!")
            break
        print("\n" + report(text) + "\n")


if __name__ == "__main__":
    main()


def analyze(text):
    """Structured result for the web UI."""
    present, results = diagnose(text)
    return {
        "symptoms": [s.replace("_", " ") for s in sorted(present)],
        "results": [{"cause": c, "pct": p, "tips": CAUSES[c][1]} for c, p in results],
        "uncertain": bool(results) and results[0][1] < 45,
    }
