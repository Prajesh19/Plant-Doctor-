const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));
const SYMPTOMS = ["yellow leaves", "brown crispy tips", "drooping", "dropping leaves", "leggy growth", "soil is always wet",
  "soil is bone dry", "tiny flies", "webbing", "mushy stem", "not growing", "direct sun", "low light", "cold draft"];

const text = $("#text");
const selected = () => text.value.toLowerCase();

function drawChips() {
  $("#chips").innerHTML = SYMPTOMS.map(s => `<button type="button" class="${selected().includes(s) ? "on" : ""}" data-s="${esc(s)}">${esc(s)}</button>`).join("");
}
$("#chips").addEventListener("click", e => {
  const s = e.target.dataset.s;
  if (!s) return;
  if (selected().includes(s)) text.value = text.value.replace(new RegExp(",?\\s*" + s, "i"), "").replace(/^[,\s]+/, "");
  else text.value = text.value.trim() ? `${text.value.trim().replace(/[,.]$/, "")}, ${s}` : s;
  drawChips();
});
text.addEventListener("input", drawChips);

function setStatus(msg, error = false) { const el = $("#status"); el.textContent = msg; el.className = error ? "error" : ""; }
function plantSick(sick) { $("#plant").classList.toggle("sick", sick); }

async function diagnose() {
  setStatus("Examining your plant…");
  $("#go").disabled = true;
  try {
    const res = await fetch("/diagnose", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({text: text.value})});
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Something went wrong.");
    show(data);
    setStatus("");
  } catch (err) {
    setStatus(err.message, true);
  } finally { $("#go").disabled = false; }
}

function show(d) {
  const out = $("#results");
  if (!d.results.length) {
    plantSick(false);
    out.innerHTML = `<div class="note">I couldn't spot any symptoms. Try describing what you see, like “yellow leaves, soil stays wet” or tap a few symptoms above.</div>`;
    return;
  }
  plantSick(true);
  out.innerHTML = `<p class="found">Symptoms I noticed: ${d.symptoms.map(esc).join(", ")}</p>` +
    d.results.map((r, i) => `<article class="card ${i === 0 ? "top" : ""}" data-top="${i === 0}">
      <h2>${esc(r.cause)} <span>~${r.pct}% of the evidence</span></h2>
      <div class="bar"><i style="width:${r.pct}%"></i></div>
      <ul class="tips">${r.tips.map(t => `<li><label><input type="checkbox"><span>${esc(t)}</span></label></li>`).join("")}</ul>
      ${i === 0 ? `<p class="fixed" hidden>Nice work. Give it a couple of weeks to respond.</p>` : ""}</article>`).join("") +
    (d.uncertain ? `<div class="note">Several causes are close. Check the soil moisture, light, and the undersides of leaves, then add those details and diagnose again.</div>` : "");
}

// Ticking off every step for the top cause perks the plant back up.
$("#results").addEventListener("change", () => {
  const top = document.querySelector('.card[data-top="true"]');
  if (!top) return;
  const boxes = [...top.querySelectorAll("input")];
  const done = boxes.every(b => b.checked);
  top.querySelector(".fixed").hidden = !done;
  plantSick(!done);
});
$("#go").onclick = diagnose;
text.addEventListener("keydown", e => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) diagnose(); });
drawChips();
